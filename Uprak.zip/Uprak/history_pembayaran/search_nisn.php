<!DOCTYPE html>
<html>
<head>
	<title>Search NISN</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="../css/style-indexed.css">
	<link rel="stylesheet" href="../css/form-cari.css">
	<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<nav>
<a href="#"><img src="../login/img/pngegg.png" class="logo" /></a>
         <ul class="navs-link">
            </div></li>
			<li><a href="../siswa-index.php">Home</a></li>
            <li><a href="login/login.php" class="button-logout">Log Out</a></li>
            
            
            
        </ul>
</nav>
	<form class="cari" autocomplete="off" action="history-siswa.php" method="post">
	<h1 align="center" style="margin-top:80px;">Masukan NISN</h1>
  <input type="text" placeholder="NISN Siswa...." name="nisn">
  <button type="submit" ><i class="fa fa-search"></i></button>
</form>
	</div>
	</form>
	
</body>
</html>
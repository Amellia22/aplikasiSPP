<!DOCTYPE html>
<html>
<head>
	<title>History Pembayaran</title>
	<link rel="stylesheet" href="css/style-indexed.css">
</head>
<body>
<nav>
<a href="#"><img src="login/img/pngegg.png" class="logo" /></a>
         <ul class="navs-link">
            </div></li>
            <li><a href="bayar_spp/bayar-petugas.php" class="button">Bayar SPP</a></li>
            <li><a href="history_pembayaran/history-petugas.php?level=Petugas" class="button-history">History Pembayaran</a></li>            
            <li><a href="login/login.php" class="button-logout">Log Out</a></li>
            
            
            
        </ul>
</nav>
    <div class="contain">
    <img class="back" src="css/sekul3.jpg" style="" alt="">
    <div class="teks-btn">
        <h2>Halo Petugas ! <br>
            Selamat Datang <br>
            Di Web SPP <span class="stu"> SMKN </span><span class="du"> 2 </span><span class="ti"> Bandung</span>
            </h2>
        <p>Yuk Mulai Bekerja Input Data Siswa <br>
        Sekarang Ga Perlu Ribet Lagi Bayar Spp  <br>
        Tinggal Inputkan Data Siswa Yang Ingin Bayar, Input Sekarang!  </p>        
    </div>
    
    <img class="logo-con" src="login/img/pngegg.png" alt="">
   <a href="bayar_spp/bayar-petugas.php"><button class="button0 button1">Bayar Spp -></button></a>
    </div>
</body>
</html>
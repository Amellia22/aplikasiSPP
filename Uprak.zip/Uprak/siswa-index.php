<!DOCTYPE html>
<html>
<head>
	<title>History Pembayaran</title>
    <link rel="stylesheet" href="css/style-indexed.css">
</head>
<body>
<nav>
<a href="#"><img src="login/img/pngegg.png" class="logo" /></a>
         <ul class="navs-link">
            </div></li> 
            <li> </li>
            <li> </li>  
            <li> </li>     
            <li> </li>    
            <li><a href="login/login.php" style="float: right;" class="button-logout">Log Out</a></li>
            
            
            
        </ul>
</nav>
    <div class="contain">
    <img class="back" src="css/sekul3.jpg" style="" alt="">
    <div class="teks-btn">
        <h2>Halo Siswa ! <br>
            Selamat Datang <br>
            Di Web SPP <span class="stu"> SMKN </span><span class="du"> 2 </span><span class="ti"> Bandung</span>
            </h2>
        <p>Yuk Mulai Bayar SPP Tepat Waktu <br>
        Agar Sekolah Kita Dapat Lebih Maju Lagi,  <br>
        Lihat Riwayat Data Pembayaran Spp Kamu Sekarang, Lihat Sekarang!  </p>        
    </div>
    
    <img class="logo-con" src="login/img/pngegg.png" alt="">
   <a href="history_pembayaran/search_nisn.php"><button style="right:155px;" class="button0 button1">History SPP -></button></a>
    </div>
</body>
</html>